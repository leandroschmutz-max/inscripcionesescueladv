# Escuela Da Vinci - Guía para Alumnos Internacionales v2
## Design Document

---

## Overview
Sitio web moderno, profesional y multiidioma (ES/EN/RU) para alumnos internacionales de Escuela Da Vinci. Basado en la estética de davinci.edu.ar: fondos oscuros, acentos fucsia, tipografía moderna, tarjetas con sombra.

---

## Part 1: Visual Design System

### Color Palette (basado en davinci.edu.ar)

| Token | HEX | Usage |
|-------|-----|-------|
| `--black` | `#0A0A0A` | Header, dark sections |
| `--dark-gray` | `#1A1A1A` | Hero, footer |
| `--medium-gray` | `#2A2A2A` | Card backgrounds on dark |
| `--light-gray` | `#F5F5F5` | Light sections |
| `--white` | `#FFFFFF` | Text on dark, cards |
| `--fuchsia` | `#E91E8C` | Primary accent, CTAs |
| `--fuchsia-dark` | `#C41775` | Hover states |
| `--teal` | `#00D4AA` | Secondary accent |
| `--text-primary` | `#1A1A1A` | Text on light |
| `--text-secondary` | `#666666` | Secondary text |
| `--text-muted` | `#999999` | Muted text |

### Typography

| Element | Font | Size | Weight |
|---------|------|------|--------|
| H1 | Inter/System | 48-64px | 800 |
| H2 | Inter/System | 36-42px | 700 |
| H3 | Inter/System | 24-28px | 600 |
| Body | Inter/System | 16-18px | 400 |
| Button | Inter/System | 14-16px | 600 |
| Nav | Inter/System | 14px | 500 |

### Components

#### Buttons
- **Primary (Fuchsia)**: bg-[#E91E8C], text-white, rounded-full, px-6 py-3
- **Secondary (Outline)**: border-2 border-[#E91E8C], text-[#E91E8C], rounded-full
- **Ghost**: text-white, hover:text-[#E91E8C]

#### Cards
- bg-white, rounded-2xl, shadow-lg
- Hover: shadow-xl, translateY(-4px)

#### Accordion
- bg-[#2A2A2A] on dark sections
- Border-left: 3px solid #E91E8C

---

## Part 2: Pages & Sections

### Global: Header
- bg-[#0A0A0A], sticky
- Logo Da Vinci left
- Nav links center (scroll-based)
- Language selector (ES/EN/RU flags) right
- Mobile: hamburger menu

### Global: Language Selector
- Dropdown with flags: 🇪🇸 ES / 🇬🇧 EN / 🇷🇺 RU
- Persist selection in localStorage

### Page: Home (/)

#### Hero Section
- Full-screen dark gradient background
- H1: "Guía para Alumnos Internacionales"
- Subtitle: "Todo lo que necesitás saber para iniciar tu carrera"
- CTA buttons: "Comenzar" + "Contactar por WhatsApp"
- Animated particles or gradient effect

#### Welcome Card
- White card overlapping hero
- Photo of Leandro + welcome text
- Contact buttons (WhatsApp, Email)

#### Quick Links Grid
- 6 cards linking to sections:
  1. Modalidad y Horarios
  2. Duración de Carreras
  3. Requisitos
  4. Pagos
  5. Evaluación
  6. Trámites Migratorios

### Page: Modalidad y Horarios (/modalidad)
- Turnos (Mañana/Tarde/Noche)
- Modalidades (Presencial/Online)
- Sistema de materias (5ta/6ta gratis)
- Cursada reducida

### Page: Carreras (/carreras)
- Grid de 7 carreras con duración
- Diseño Web: 2 años
- Resto: 3 años
- Carrera de Cine solo presencial

### Page: Requisitos (/requisitos)
- Pasaporte vigente
- Título secundario con convalidación
- Pago de matrícula
- Info sobre convalidación digital
- Plazo hasta 31 de octubre

### Page: Pagos (/pagos)
- Matrícula semestral vs anual
- Plan de 10 cuotas vs 12 cuotas
- Pagos desde el exterior (PayPal)

### Page: Evaluación (/evaluacion)
- Trabajos prácticos y parciales
- Exámenes finales (costo adicional)
- Requisito de convalidación para rendir

### Page: Trámites Migratorios (/migratorios)
- Certificado de Inscripción Electrónica
- Requisitos DNM (matriculado, pasaporte, título convalidado)
- Modalidad online y presencial
- Clases solo en español

### Global: Footer
- bg-[#0A0A0A]
- Logo + tagline
- Quick links
- Contact info
- Copyright

---

## Part 3: Multi-language Structure

Using react-i18next with 3 namespaces:
- `common` - UI elements (nav, buttons, footer)
- `home` - Home page content
- `guide` - All guide sections (modalidad, carreras, requisitos, pagos, evaluacion, migratorios)

### Files:
- `/public/locales/es/common.json`
- `/public/locales/en/common.json`
- `/public/locales/ru/common.json`
- Same for home.json and guide.json
