import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import './i18n';
import Header from './components/layout/Header';
import HomePage from './pages/HomePage';
import GuidePage from './pages/GuidePage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-[#0A0A0A] text-white">
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/:section" element={<GuidePage />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
