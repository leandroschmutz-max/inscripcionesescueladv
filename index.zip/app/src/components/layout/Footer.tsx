import { useTranslation } from 'react-i18next';
import { MapPin, MessageCircle, Mail } from 'lucide-react';

const Footer = () => {
  const { t } = useTranslation('common');

  return (
    <footer className="bg-[#0A0A0A] border-t border-white/5">
      <div className="section-container py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Brand */}
          <div>
            <h3 className="text-white font-bold text-lg mb-2">Da Vinci</h3>
            <p className="text-gray-500 text-sm">{t('footer.tagline')}</p>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-3">{t('contact.title')}</h4>
            <div className="space-y-2">
              <a
                href="https://api.whatsapp.com/send/?phone=5491171692687"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-[#E91E8C] text-sm transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </a>
              <a
                href="mailto:leandro.schmutz@davinci.edu.ar"
                className="flex items-center gap-2 text-gray-400 hover:text-[#E91E8C] text-sm transition-colors"
              >
                <Mail className="w-4 h-4" />
                leandro.schmutz@davinci.edu.ar
              </a>
              <div className="flex items-center gap-2 text-gray-500 text-sm">
                <MapPin className="w-4 h-4" />
                Av. Corrientes 2037, CABA
              </div>
            </div>
          </div>

          {/* Form */}
          <div>
            <h4 className="text-white font-semibold mb-3">{t('nav.form')}</h4>
            <a
              href="https://forms.gle/Kuau66A93sHnbDAa8"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-fuchsia text-sm inline-block"
            >
              {t('cta.form')}
            </a>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/5 text-center">
          <p className="text-gray-600 text-xs">{t('footer.confidential')}</p>
          <p className="text-gray-700 text-xs mt-1">{t('footer.copyright')}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
