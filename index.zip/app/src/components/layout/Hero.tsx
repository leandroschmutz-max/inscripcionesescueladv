import { useTranslation } from 'react-i18next';
import { MessageCircle, FileText } from 'lucide-react';

const Hero = () => {
  const { t } = useTranslation('common');

  return (
    <section className="relative dv-gradient-hero min-h-[80vh] flex items-center overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-[#E91E8C]/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#7B2D8E]/10 rounded-full blur-3xl" />
      
      <div className="section-container relative z-10 py-20">
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 mb-6">
            <span className="px-3 py-1 bg-[#E91E8C]/20 text-[#E91E8C] text-sm font-medium rounded-full border border-[#E91E8C]/30">
              2026
            </span>
            <span className="text-gray-400 text-sm">Escuela Da Vinci</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6">
            {t('hero.title')}
          </h1>
          
          <p className="text-lg md:text-xl text-gray-400 mb-8 leading-relaxed">
            {t('hero.subtitle')}
          </p>
          
          <div className="flex flex-wrap gap-4">
            <a
              href="https://forms.gle/Kuau66A93sHnbDAa8"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-fuchsia flex items-center gap-2"
            >
              <FileText className="w-5 h-5" />
              {t('cta.form')}
            </a>
            <a
              href="https://api.whatsapp.com/send/?phone=5491171692687"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-outline-fuchsia flex items-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              {t('cta.whatsapp')}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
