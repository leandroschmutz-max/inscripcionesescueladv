const CTABar = () => {
  return (
    <section className="bg-[#6B3A8C] py-6">
      <div className="section-container text-center">
        <a
          href="https://forms.gle/Kuau66A93sHnbDAa8"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-white text-[#6B3A8C] border border-[#6B3A8C] px-8 py-3 rounded text-sm font-medium uppercase tracking-wide hover:bg-gray-50 transition-all duration-200 hover:scale-[1.02]"
        >
          Formulario Inscripción
        </a>
      </div>
    </section>
  );
};

export default CTABar;
