import { MessageCircle, Globe, Mail } from 'lucide-react';

const ContactBar = () => {
  return (
    <section className="bg-white py-6 border-b border-gray-100">
      <div className="section-container">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <span className="text-gray-700 font-medium">Medios de contacto:</span>
          <div className="flex items-center gap-4">
            {/* WhatsApp */}
            <a
              href="https://api.whatsapp.com/send/?phone=5491171692687"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-[#25D366] flex items-center justify-center text-white hover:scale-110 transition-transform"
              aria-label="WhatsApp"
            >
              <MessageCircle className="w-5 h-5" />
            </a>
            
            {/* Website */}
            <a
              href="https://davinci.edu.ar/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-[#333333] flex items-center justify-center text-white hover:scale-110 transition-transform"
              aria-label="Sitio web"
            >
              <Globe className="w-5 h-5" />
            </a>
            
            {/* Email */}
            <a
              href="mailto:leandro.schmutz@davinci.edu.ar"
              className="w-10 h-10 rounded-full bg-[#333333] flex items-center justify-center text-white hover:scale-110 transition-transform"
              aria-label="Email"
            >
              <Mail className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactBar;
