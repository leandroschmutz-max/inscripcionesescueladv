import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface AccordionItemProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
  variant?: 'default' | 'purple';
}

export const AccordionItem = ({ 
  title, 
  children, 
  defaultOpen = false,
  variant = 'default'
}: AccordionItemProps) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  const headerClass = variant === 'purple' 
    ? (isOpen ? 'bg-[#6B3A8C] text-white' : 'bg-gray-100 text-[#6B3A8C]')
    : 'bg-gray-100 text-gray-800';

  return (
    <div className="border-b border-gray-200">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full flex items-center justify-between py-4 px-4 md:px-6 text-left transition-all duration-300 ${headerClass}`}
      >
        <span className="font-serif text-lg md:text-xl">{title}</span>
        <ChevronDown 
          className={`w-6 h-6 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} 
        />
      </button>
      <div 
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="py-4 px-4 md:px-6 bg-white">
          {children}
        </div>
      </div>
    </div>
  );
};

interface AccordionProps {
  children: React.ReactNode;
}

const Accordion = ({ children }: AccordionProps) => {
  return (
    <div className="w-full">
      {children}
    </div>
  );
};

export default Accordion;
