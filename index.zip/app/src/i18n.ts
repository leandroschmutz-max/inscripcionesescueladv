import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

import esCommon from './locales/es/common.json';
import enCommon from './locales/en/common.json';
import ruCommon from './locales/ru/common.json';

import esHome from './locales/es/home.json';
import enHome from './locales/en/home.json';
import ruHome from './locales/ru/home.json';

import esGuide from './locales/es/guide.json';
import enGuide from './locales/en/guide.json';
import ruGuide from './locales/ru/guide.json';

const resources = {
  es: { common: esCommon, home: esHome, guide: esGuide },
  en: { common: enCommon, home: enHome, guide: enGuide },
  ru: { common: ruCommon, home: ruHome, guide: ruGuide },
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'es',
    interpolation: { escapeValue: false },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
    },
  });

export default i18n;
