export interface Carrera {
  id: string;
  nombre: string;
  slug: string;
  matricula: {
    semestral: string;
    anual: string;
  };
  presencial: {
    plan12: {
      manana: string;
      tarde: string;
      noche: string;
    };
    plan10: {
      manana: string;
      tarde: string;
      noche: string;
    };
  };
  virtual: {
    plan12: {
      manana: string;
      tarde: string;
      noche: string;
    };
    plan10: {
      manana: string;
      tarde: string;
      noche: string;
    };
  };
}

export const carreras: Carrera[] = [
  {
    id: '1',
    nombre: 'Diseño Multimedial',
    slug: 'diseno-multimedial',
    matricula: {
      semestral: '$211.000',
      anual: '$385.000',
    },
    presencial: {
      plan12: {
        manana: '$484.400',
        tarde: '$410.800',
        noche: '$391.200',
      },
      plan10: {
        manana: '$554.800',
        tarde: '$466.800',
        noche: '$446.800',
      },
    },
    virtual: {
      plan12: {
        manana: '$391.200',
        tarde: '$391.200',
        noche: '$391.200',
      },
      plan10: {
        manana: '$446.800',
        tarde: '$446.800',
        noche: '$446.800',
      },
    },
  },
  {
    id: '2',
    nombre: 'Diseño Gráfico Artístico Digital',
    slug: 'diseno-grafico',
    matricula: {
      semestral: '$211.000',
      anual: '$385.000',
    },
    presencial: {
      plan12: {
        manana: '$484.400',
        tarde: '$410.800',
        noche: '$391.200',
      },
      plan10: {
        manana: '$554.800',
        tarde: '$466.800',
        noche: '$446.800',
      },
    },
    virtual: {
      plan12: {
        manana: '$391.200',
        tarde: '$391.200',
        noche: '$391.200',
      },
      plan10: {
        manana: '$446.800',
        tarde: '$446.800',
        noche: '$446.800',
      },
    },
  },
  {
    id: '3',
    nombre: 'Videojuegos',
    slug: 'videojuegos',
    matricula: {
      semestral: '$211.000',
      anual: '$385.000',
    },
    presencial: {
      plan12: {
        manana: '$484.400',
        tarde: '$410.800',
        noche: '$391.200',
      },
      plan10: {
        manana: '$554.800',
        tarde: '$466.800',
        noche: '$446.800',
      },
    },
    virtual: {
      plan12: {
        manana: '$391.200',
        tarde: '$391.200',
        noche: '$391.200',
      },
      plan10: {
        manana: '$446.800',
        tarde: '$446.800',
        noche: '$446.800',
      },
    },
  },
  {
    id: '4',
    nombre: 'Cine de Animación',
    slug: 'cine-animacion',
    matricula: {
      semestral: '$211.000',
      anual: '$385.000',
    },
    presencial: {
      plan12: {
        manana: '$484.400',
        tarde: '$410.800',
        noche: '$391.200',
      },
      plan10: {
        manana: '$554.800',
        tarde: '$466.800',
        noche: '$446.800',
      },
    },
    virtual: {
      plan12: {
        manana: '$391.200',
        tarde: '$391.200',
        noche: '$391.200',
      },
      plan10: {
        manana: '$446.800',
        tarde: '$446.800',
        noche: '$446.800',
      },
    },
  },
  {
    id: '5',
    nombre: 'Cine y Nuevos Formatos',
    slug: 'cine-nuevos-formatos',
    matricula: {
      semestral: '$211.000',
      anual: '$385.000',
    },
    presencial: {
      plan12: {
        manana: '$484.400',
        tarde: '$410.800',
        noche: '$391.200',
      },
      plan10: {
        manana: '$554.800',
        tarde: '$466.800',
        noche: '$446.800',
      },
    },
    virtual: {
      plan12: {
        manana: '$391.200',
        tarde: '$391.200',
        noche: '$391.200',
      },
      plan10: {
        manana: '$446.800',
        tarde: '$446.800',
        noche: '$446.800',
      },
    },
  },
  {
    id: '6',
    nombre: 'Diseño Web',
    slug: 'diseno-web',
    matricula: {
      semestral: '$211.000',
      anual: '$385.000',
    },
    presencial: {
      plan12: {
        manana: '$484.400',
        tarde: '$410.800',
        noche: '$391.200',
      },
      plan10: {
        manana: '$554.800',
        tarde: '$466.800',
        noche: '$446.800',
      },
    },
    virtual: {
      plan12: {
        manana: '$391.200',
        tarde: '$391.200',
        noche: '$391.200',
      },
      plan10: {
        manana: '$446.800',
        tarde: '$446.800',
        noche: '$446.800',
      },
    },
  },
  {
    id: '7',
    nombre: 'Analista de Sistemas',
    slug: 'analista-sistemas',
    matricula: {
      semestral: '$211.000',
      anual: '$385.000',
    },
    presencial: {
      plan12: {
        manana: '$484.400',
        tarde: '$410.800',
        noche: '$391.200',
      },
      plan10: {
        manana: '$554.800',
        tarde: '$466.800',
        noche: '$446.800',
      },
    },
    virtual: {
      plan12: {
        manana: '$391.200',
        tarde: '$391.200',
        noche: '$391.200',
      },
      plan10: {
        manana: '$446.800',
        tarde: '$446.800',
        noche: '$446.800',
      },
    },
  },
];

export const getCarreraBySlug = (slug: string): Carrera | undefined => {
  return carreras.find((c) => c.slug === slug);
};
