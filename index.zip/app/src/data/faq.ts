export interface FAQItem {
  id: string;
  pregunta: string;
  respuesta: string;
}

export const faqItems: FAQItem[] = [
  {
    id: '1',
    pregunta: '¿Cuándo comienza la cursada?',
    respuesta: 'Las clases comienzan en la semana del 16 de marzo.',
  },
  {
    id: '2',
    pregunta: '¿Qué días se cursa?',
    respuesta: 'Se cursa 3 veces por semana. Los días específicos te serán confirmados a finales de febrero. (No se cursa los días sábados).',
  },
  {
    id: '3',
    pregunta: '¿Puedo abonar la matrícula con tarjeta de crédito?',
    respuesta: 'Sí, en ese caso te pido que envíes el formulario, y me avises por whatsapp o mail así te envío el link de pago para que puedas abonar.',
  },
  {
    id: '4',
    pregunta: '¿Cuándo comienzo a pagar la primera mensualidad?',
    respuesta: 'Comenzarás a pagar las cuotas recién en marzo. Tendrás tiempo hasta el 31 de marzo para abonar la primera mensualidad, y luego tendrás hasta el 10 de cada mes para las siguientes.',
  },
  {
    id: '5',
    pregunta: '¿Puedo anotarme adeudando materias del secundario?',
    respuesta: 'Sí, vos reservas ya la vacante para marzo 2026, te anotamos como alumn@ condicional y tendrás hasta junio 2026 para presentar el título o la constancia de título en trámite, lo único que debes tener en cuenta es que no puedes adeudar más de 2 materias. En caso de que llegues a junio y no presentes la documentación podrás seguir cursando hasta octubre 2026. Sin embargo no podrás rendir finales en Agosto (los mismos podrás rendirlos en diciembre).',
  },
  {
    id: '6',
    pregunta: '¿Cómo es la cursada online?',
    respuesta: 'La cursada online es completamente virtual es decir que tanto los parciales/trabajos prácticos/ finales se rinden de forma remota, vas a tener clases sincrónicas, es decir que el profesor va a estar en vivo para que puedas ir trabajando a la par y despejar tus dudas, además las clases quedan grabadas y se suben al google calendar para que puedas volverlas a ver en caso de necesitarlo.',
  },
  {
    id: '7',
    pregunta: '¿Dónde puedo realizar el pago de la matrícula?',
    respuesta: 'Al finalizar el formulario de inscripción encontrarás los datos bancarios de la escuela para realizar la transferencia. También puedes abonar con tarjeta de crédito solicitando el link de pago por WhatsApp o email.',
  },
  {
    id: '8',
    pregunta: '¿La mensualidad tiene actualizaciones?',
    respuesta: 'Sí, los aranceles se actualizan trimestralmente según el índice de inflación. Te mantendremos informado sobre cualquier cambio con anticipación.',
  },
  {
    id: '9',
    pregunta: '¿Tengo que tener una PC con ciertos requisitos?',
    respuesta: 'Sí, para la cursada virtual es necesario contar con una computadora que cumpla con los requisitos mínimos de la carrera. Cada carrera tiene sus especificaciones particulares que te serán enviadas al momento de la inscripción.',
  },
  {
    id: '10',
    pregunta: '¿Los finales se abonan aparte?',
    respuesta: 'No, el valor de la cuota mensual incluye el derecho a rendir exámenes finales. No hay costos adicionales por los finales.',
  },
  {
    id: '11',
    pregunta: '¿Puedo cursar menos materias?',
    respuesta: 'Sí, podés cursar la carrera a tu ritmo. Si necesitás cursar menos materias por cuestiones de tiempo o trabajo, podemos armar un plan de estudios personalizado.',
  },
  {
    id: '12',
    pregunta: '¿Cuentan con becas?',
    respuesta: 'Sí, la escuela cuenta con un programa de becas. Podés consultar las opciones disponibles y los requisitos contactándome por WhatsApp o email.',
  },
  {
    id: '13',
    pregunta: '¿Donde puedo ver el plan de estudios?',
    respuesta: 'El plan de estudios de cada carrera está disponible en el sitio web oficial de la escuela: davinci.edu.ar. También te lo puedo enviar por email o WhatsApp si lo solicitás.',
  },
  {
    id: '14',
    pregunta: '¿Qué sigue después de anotarme?',
    respuesta: 'Una vez que completes el formulario y abones la matrícula, recibirás un email de confirmación con los próximos pasos. Te enviaremos información sobre la fecha de inicio, el calendario académico y los accesos a la plataforma.',
  },
  {
    id: '15',
    pregunta: '¿Cuándo me envían los accesos y cuándo puedo solicitar la constancia de inscripción o alumno regular?',
    respuesta: 'Los accesos a la plataforma se envían una semana antes del inicio de clases. La constancia de inscripción se puede solicitar inmediatamente después de abonar la matrícula, y la de alumno regular se emitirá una vez que comience la cursada.',
  },
  {
    id: '16',
    pregunta: '¿Cuentan con débito automático para el pago de la cuota?',
    respuesta: 'Sí, ofrecemos la opción de débito automático para el pago de las cuotas mensuales. Podés adherirte completando un formulario que te enviaremos por email.',
  },
  {
    id: '17',
    pregunta: '¿Puedo hacer el pago del año por adelantado?',
    respuesta: 'Sí, ofrecemos descuentos especiales para pagos adelantados. Consultame por WhatsApp o email para conocer las opciones y beneficios disponibles.',
  },
];
