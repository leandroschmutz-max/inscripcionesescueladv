import { useTranslation } from 'react-i18next';
import { Link, useParams } from 'react-router-dom';
import Footer from '../components/layout/Footer';
import { 
  Clock, GraduationCap, FileCheck, CreditCard, 
  ClipboardCheck, Plane, ArrowLeft 
} from 'lucide-react';

type SectionKey = 'modality' | 'careers' | 'requirements' | 'payments' | 'evaluation' | 'immigration';

const sectionConfig: Record<SectionKey, { icon: typeof Clock; gradient: string }> = {
  modality: { icon: Clock, gradient: 'from-pink-500 to-rose-500' },
  careers: { icon: GraduationCap, gradient: 'from-purple-500 to-violet-500' },
  requirements: { icon: FileCheck, gradient: 'from-blue-500 to-cyan-500' },
  payments: { icon: CreditCard, gradient: 'from-emerald-500 to-teal-500' },
  evaluation: { icon: ClipboardCheck, gradient: 'from-amber-500 to-orange-500' },
  immigration: { icon: Plane, gradient: 'from-indigo-500 to-blue-500' },
};

const GuidePage = () => {
  const { section } = useParams<{ section: string }>();
  const { t } = useTranslation('guide');
  const { t: tCommon } = useTranslation('common');

  const sectionKey = section as SectionKey;
  const config = sectionConfig[sectionKey];

  if (!config) return null;

  const Icon = config.icon;

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      <section className="dv-gradient-hero py-16 md:py-24">
        <div className="section-container">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-gray-400 hover:text-white text-sm mb-8 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            {tCommon('cta.back')}
          </Link>
          <div className="flex items-center gap-4 mb-4">
            <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${config.gradient} flex items-center justify-center`}>
              <Icon className="w-7 h-7 text-white" />
            </div>
            <div className="accent-line" />
          </div>
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-white">
            {t(`${sectionKey}.title`)}
          </h1>
        </div>
      </section>

      <section className="py-12">
        <div className="section-container max-w-4xl">
          <div className="space-y-6">
            <ContentBlocks section={sectionKey} t={t} />
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

const ContentBlocks = ({ section, t }: { section: SectionKey; t: any }) => {
  switch (section) {
    case 'modality':
      return <ModalityContent t={t} />;
    case 'careers':
      return <CareersContent t={t} />;
    case 'requirements':
      return <RequirementsContent t={t} />;
    case 'payments':
      return <PaymentsContent t={t} />;
    case 'evaluation':
      return <EvaluationContent t={t} />;
    case 'immigration':
      return <ImmigrationContent t={t} />;
    default:
      return null;
  }
};

const Card = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => (
  <div className={`bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 ${className}`}>{children}</div>
);

const H3 = ({ children }: { children: React.ReactNode }) => (
  <h3 className="text-xl font-semibold text-white mb-3">{children}</h3>
);

const P = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => (
  <p className={`text-gray-300 leading-relaxed ${className}`}>{children}</p>
);

const LI = ({ children }: { children: React.ReactNode }) => (
  <li className="text-gray-300 leading-relaxed flex gap-3">
    <span className="text-[#E91E8C] flex-shrink-0 mt-1">•</span>
    <span>{children}</span>
  </li>
);

const ModalityContent = ({ t }: { t: any }) => (
  <>
    <Card>
      <H3>{t('modality.schedule.title')}</H3>
      <P>{t('modality.schedule.desc')}</P>
      <ul className="mt-4 space-y-2">
        <LI>{t('modality.schedule.morning')}</LI>
        <LI>{t('modality.schedule.afternoon')}</LI>
        <LI>{t('modality.schedule.night')}</LI>
      </ul>
    </Card>

    <Card>
      <H3>{t('modality.subjects.title')}</H3>
      <div className="space-y-3">
        <P>{t('modality.subjects.new')}</P>
        <P>{t('modality.subjects.continuing')}</P>
        <div className="border-l-2 border-[#E91E8C] pl-4 mt-4 space-y-2">
          <P>{t('modality.subjects.pricing')}</P>
          <P className="text-[#E91E8C]">{t('modality.subjects.bonus5')}</P>
          <P className="text-[#E91E8C]">{t('modality.subjects.bonus6')}</P>
          <P>{t('modality.subjects.reduced')}</P>
          <P className="text-gray-400 italic">{t('modality.subjects.example')}</P>
        </div>
      </div>
    </Card>

    <Card>
      <H3>{t('modality.options.title')}</H3>
      <ul className="space-y-3">
        <LI>{t('modality.options.inPerson')}</LI>
        <LI>{t('modality.options.online')}</LI>
        <LI>{t('modality.options.recorded')}</LI>
      </ul>
    </Card>
  </>
);

const CareersContent = ({ t }: { t: any }) => (
  <Card>
    <P className="mb-6">{t('careers.desc')}</P>
    <div className="grid gap-3">
      {['web', 'systems', 'multimedia', 'graphic', 'games', 'animation', 'film'].map((key) => (
        <div key={key} className="flex items-center gap-4 p-4 bg-white/5 rounded-xl border border-white/5">
          <div className="w-2 h-2 rounded-full bg-[#E91E8C]" />
          <P>{t(`careers.${key}`)}</P>
        </div>
      ))}
    </div>
  </Card>
);

const RequirementsContent = ({ t }: { t: any }) => (
  <>
    <Card>
      <P className="mb-4">{t('requirements.desc')}</P>
      <ul className="space-y-3">
        <LI>{t('requirements.passport')}</LI>
        <LI>{t('requirements.degree')}</LI>
        <LI>{t('requirements.deadline')}</LI>
        <LI>{t('requirements.payment')}</LI>
      </ul>
    </Card>

    <Card className="border-l-4 border-l-[#E91E8C]">
      <H3>{t('requirements.validation.title')}</H3>
      <P>{t('requirements.validation.desc')}</P>
      <a
        href="https://www.argentina.gob.ar/educacion/convalidacion"
        target="_blank"
        rel="noopener noreferrer"
        className="inline-block mt-4 text-[#E91E8C] hover:text-[#FF6B9D] underline text-sm"
      >
        {t('requirements.validation.link')}
      </a>
    </Card>
  </>
);

const PaymentsContent = ({ t }: { t: any }) => (
  <>
    <Card>
      <H3>{t('payments.enrollment.title')}</H3>
      <P className="mb-4">{t('payments.enrollment.desc')}</P>
      <ul className="space-y-3">
        <LI>{t('payments.enrollment.semester')}</LI>
        <LI>{t('payments.enrollment.annual')}</LI>
      </ul>
    </Card>

    <Card>
      <H3>{t('payments.monthly.title')}</H3>
      <P className="mb-4">{t('payments.monthly.desc')}</P>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 bg-white/5 rounded-xl border border-white/5">
          <h4 className="text-white font-semibold mb-2">10 {t('payments.monthly.plan10').split(':')[0]}</h4>
          <P>{t('payments.monthly.plan10').split(':')[1]}</P>
        </div>
        <div className="p-4 bg-white/5 rounded-xl border border-[#E91E8C]/20">
          <h4 className="text-[#E91E8C] font-semibold mb-2">12 {t('payments.monthly.plan12').split(':')[0]}</h4>
          <P>{t('payments.monthly.plan12').split(':')[1]}</P>
        </div>
      </div>
    </Card>

    <Card className="border-l-4 border-l-[#00D4AA]">
      <P className="text-[#00D4AA] font-medium">{t('payments.intl')}</P>
    </Card>
  </>
);

const EvaluationContent = ({ t }: { t: any }) => (
  <>
    <Card>
      <P>{t('evaluation.desc')}</P>
    </Card>

    <Card className="border-l-4 border-l-amber-500">
      <h4 className="text-amber-400 font-semibold mb-2">⚠️ {t('evaluation.title')}</h4>
      <P>{t('evaluation.cost')}</P>
    </Card>

    <Card className="border-l-4 border-l-[#E91E8C]">
      <P className="text-[#E91E8C] font-medium">{t('evaluation.requirement')}</P>
    </Card>
  </>
);

const ImmigrationContent = ({ t }: { t: any }) => (
  <>
    <Card>
      <P>{t('immigration.desc')}</P>
    </Card>

    <Card>
      <H3>{t('immigration.certificate.title')}</H3>
      <P className="mb-4">{t('immigration.certificate.desc')}</P>
      <ul className="space-y-3">
        <LI>{t('immigration.certificate.req1')}</LI>
        <LI>{t('immigration.certificate.req2')}</LI>
        <LI>{t('immigration.certificate.req3')}</LI>
      </ul>
    </Card>

    <Card>
      <H3>{t('immigration.info.title')}</H3>
      <ul className="space-y-3">
        <LI>{t('immigration.info.i1')}</LI>
        <LI>{t('immigration.info.i2')}</LI>
        <LI>{t('immigration.info.i3')}</LI>
        <LI>{t('immigration.info.i4')}</LI>
        <LI>{t('immigration.info.i5')}</LI>
      </ul>
    </Card>
  </>
);

export default GuidePage;
