import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Hero from '../components/layout/Hero';
import Footer from '../components/layout/Footer';
import { 
  Clock, GraduationCap, FileCheck, CreditCard, 
  ClipboardCheck, Plane, MessageCircle, Mail, MapPin 
} from 'lucide-react';

const HomePage = () => {
  const { t } = useTranslation(['common', 'home']);

  const sections = [
    { key: 'modality', icon: Clock, path: '/modalidad', color: 'from-pink-500 to-rose-500' },
    { key: 'careers', icon: GraduationCap, path: '/carreras', color: 'from-purple-500 to-violet-500' },
    { key: 'requirements', icon: FileCheck, path: '/requisitos', color: 'from-blue-500 to-cyan-500' },
    { key: 'payments', icon: CreditCard, path: '/pagos', color: 'from-emerald-500 to-teal-500' },
    { key: 'evaluation', icon: ClipboardCheck, path: '/evaluacion', color: 'from-amber-500 to-orange-500' },
    { key: 'immigration', icon: Plane, path: '/migratorios', color: 'from-indigo-500 to-blue-500' },
  ];

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      <Hero />

      {/* Welcome Section */}
      <section className="relative -mt-20 z-10 pb-16">
        <div className="section-container">
          <div className="dv-card p-6 md:p-8 max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="flex-shrink-0 mx-auto md:mx-0">
                <div className="w-32 h-32 md:w-40 md:h-40 rounded-2xl overflow-hidden border-2 border-[#E91E8C]/30">
                  <img
                    src="/leandro.jpg"
                    alt="Leandro"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
                  {t('common:welcome.title')}
                </h2>
                <div className="space-y-3 text-gray-300 leading-relaxed">
                  <p>{t('common:welcome.p1')}</p>
                  <p>{t('common:welcome.p2')}</p>
                  <p>{t('common:welcome.p3')}</p>
                  <p className="text-[#E91E8C]">{t('common:welcome.p4')}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Links Grid */}
      <section className="py-12">
        <div className="section-container">
          <h2 className="text-2xl md:text-3xl font-bold text-white text-center mb-10">
            {t('home:quickLinks.title')}
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {sections.map(({ key, icon: Icon, path, color }) => (
              <Link
                key={key}
                to={path}
                className="dv-card-hover p-6 group"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  {t(`home:quickLinks.${key}.title`)}
                </h3>
                <p className="text-gray-400 text-sm">
                  {t(`home:quickLinks.${key}.desc`)}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-12 border-t border-white/5">
        <div className="section-container">
          <div className="dv-card p-8 max-w-2xl mx-auto text-center">
            <h3 className="text-xl font-bold text-white mb-2">{t('home:contact.title')}</h3>
            <p className="text-gray-400 mb-6">{t('home:contact.desc')}</p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="https://api.whatsapp.com/send/?phone=5491171692687"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-fuchsia flex items-center gap-2"
              >
                <MessageCircle className="w-5 h-5" />
                {t('home:contact.whatsapp')}
              </a>
              <a
                href="mailto:leandro.schmutz@davinci.edu.ar"
                className="btn-outline-fuchsia flex items-center gap-2"
              >
                <Mail className="w-5 h-5" />
                {t('home:contact.email')}
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Location */}
      <section className="py-8 pb-16">
        <div className="section-container text-center">
          <div className="flex items-center justify-center gap-2 text-gray-500">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">{t('home:location.address')}</span>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HomePage;
